Use the WAMPSERVER - PYPMYADMIN - MYSQL to run this prototype
---------------------------------------------------------------------------------------------

Folder Path:c:\wamp64\www\...\hospital
Import the database.sql to phpmyadmin under the datatabase name: "database"
---------------------------------------------------------------------------------------------
=============================================================================================
List of File and Use:

dropdown.php  - File to create a new ED record
ed.php - Read the record of ED and perform update and delete operation.
ed.1php - File to store the record of created ED record using drowpdown.php page.
ed_delete.php - File to process delete function.
mystyle.css - CSS file for webpage design
style.css - CSS file for webpage design
update1.php - File to perform update functionality.
update_process.php - File to process update function and store updated record.
upload.php - Page to allow user to upload csv file and store the data to database.


============================================================================================

List of dataset CSV files 


DS3B CARDIAC data.csv
DS6B BloodProductAudit clinical data.csv
DS7E PAM Cardiac Surgery data.csv

--------------------------------------------------------------------------------------------

- Limitation: 
This prototype will allow user to upload 3 dataset files only. (As mentioned above)
All 3-dataset file should be under the same folder with the code.
CSV dataset files name should be as given here on readme file prototype will store the value using those names only.
If user will try to upload a same dataset file again, will get message to try uploading another file.
===================================================================================================


Information about database - "database"

-Some of the sample data has been inserted.
-All 3 dataset files have been already uploaded. 
-To check the functionality of uploading csv file run this query to delete a exsiting uploaded dataset using related dataset_id.
	DELETE FROM `raw_column_data` WHERE dataset_id=1; 
-Get the relevent dataset_id using table of dataset_list and replace 1 with relevant dataset_id.
