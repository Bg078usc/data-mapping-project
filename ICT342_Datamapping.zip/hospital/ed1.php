    <?php
    // MySQL connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "database";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    echo '<br>';
    echo '<br>';

 

//Check if the form is submitted
if (isset($_POST['submit_data'])) {
    $DATASET=$_POST['DATASET'];
    $EVENT_NAME = $_POST['event'];
    $CLIN_DSET_DESCR=$_POST['CLIN_DSET_DESCR'];
    $CLIN_DSET_NAME=$_POST['CLIN_DSET_NAME'];
    $PK=$_POST['PK'];
    $PATIENT_ID=$_POST['PATIENT_ID'];
    $DOB=$_POST['DOB'];
    $SEX = $_POST['SEX'];
    $HEIGHT = $_POST['HEIGHT'];
    $WEIGHT = $_POST['WEIGHT'];
    $COMMENT = $_POST['COMMENT'];
    $PK_ORIGIN = $_POST['PK_ORIGIN'];
    $BOC_EVENT = $_POST['BOC_EVENT'];
    $CLOSEST_DATE = $_POST['CLOSEST_DATE'];
    $CLOSEST_DATE_EVENT = $_POST['CLOSEST_DATE_EVENT'];
    $HB = $_POST['HB'];
    $HCT = $_POST['HCT'];
    $RCC = $_POST['RCC'];
    $MCV = $_POST['MCV'];
    $RETIC = $_POST['RETIC'];
    $PRBC = $_POST['PRBC'];
    $HAEMOSTAT_INTERVENE = $_POST['HAEMOSTAT_INTERVENE'];
    $ON_PUMP = $_POST['ON_PUMP'];
    $PRIMARY_OPERATION = $_POST['PRIMARY_OPERATION'];
    $CS_URGENCY = $_POST['CS_URGENCY'];
    $DIAGNOSIS = $_POST['DIAGNOSIS'];
    $TREATMENT = $_POST['TREATMENT'];
    $RAW_DATA = $_POST['RAW_DATA'];

    

    $sql = "INSERT INTO event_defination(`DATASET`,`EVENT`,  `CLIN.DSET.DESCR`, `CLIN.DSET.NAME`, `PK`, `PATIENT.ID`, `DOB`, `SEX`, `HEIGHT`, `WEIGHT`, `COMMENT`, `PK.ORIGIN`, `BOC.EVENT`, `CLOSEST.DATE`, `CLOSEST.DATE.EVENT`, `HB`, `HCT`, `RCC`, `MCV`, `RETIC`, `PRBC`, `HAEMOSTAT.INTERVENE`, `ON.PUMP`, `PRIMARY.OPERATION`, `CS.URGENCY`, `DIAGNOSIS`, `TREATMENT`, `RAW.DATA`) 
    VALUES ('$DATASET','$EVENT_NAME','$CLIN_DSET_DESCR','$CLIN_DSET_NAME','$PK','$PATIENT_ID','$DOB','$SEX','$HEIGHT','$WEIGHT','$COMMENT','$PK_ORIGIN','$BOC_EVENT','$CLOSEST_DATE','$CLOSEST_DATE_EVENT','$HB','$HCT','$RCC','$MCV','$RETIC','$PRBC','$HAEMOSTAT_INTERVENE','$ON_PUMP','$PRIMARY_OPERATION','$CS_URGENCY','$DIAGNOSIS','$TREATMENT','$RAW_DATA')";
    
            if(mysqli_query($conn,$sql))
                {
                    echo "Record created successfully";
                    header("location:ed.php");
                }

}

    // Close the database connection
    $conn->close();
    ?>

