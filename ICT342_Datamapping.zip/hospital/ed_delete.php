<?php
$con=mysqli_connect("localhost","root","","database");

$sql="DELETE FROM event_defination WHERE ed_id='$_GET[id]'";

if(mysqli_query($con,$sql))
	header("refresh:0.1; url=ed.php")
?>