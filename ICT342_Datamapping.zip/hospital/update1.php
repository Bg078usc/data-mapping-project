<?php
// Check if the record ID is provided in the URL
if (isset($_GET['id'])) {
    $recordId = $_GET['id'];

    // MySQL connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "database";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }



    // Close the database connection
 
}
?>

<!-- Display the update form with the retrieved record values -->
<html>
<head>
    <title>Be strong - Admin</title>
    <link rel="stylesheet" type="text/css" href="mystyle.css">
    <!-- favicons
    ================================================== -->
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">
</head>
<body>
<br/>
<center>
    <font color="green" size="10">Be Healthy</font>
</center>
<ul>
    <li><a href="dropdown.php">Create a new record</a></li>
    <li><a class="active" href="ed.php">Event Definition List</a></li>
    <li><a href="upload.php">Upload Dataset CSV file</a></li>
</ul>
<div class="container">
    <center>
        <form name="ed" action="update_process.php" method="POST">
            <input type="hidden" name="record_id" value="<?php echo $recordId; ?>">
            
            <!-- Display the form fields with the retrieved record values -->
           
             <?php  
           // Fetch the data from the database
        $sql4 = "SELECT variableColumnName FROM standrd_name where standrdNameID > 1";
        $result4 = mysqli_query($conn, $sql4);

        // Check for errors in the query
        if (!$result4) {
            die("Query failed: " . $conn->error);
        }

        // Create an array to store the column names
        $columnNames = array();
        while ($row4 = mysqli_fetch_assoc($result4)) {
            $columnNames[] = $row4['variableColumnName'];
        }

        // Get the right dataset id from table
        $sql5 = "SELECT DATASET FROM event_defination where ed_id = $recordId";
        $dataset_result = mysqli_query($conn, $sql5);

        if (!$dataset_result) {
            die("Query failed: " . $conn->error);
        }

        $dataset_row = mysqli_fetch_assoc($dataset_result);
        $dataset_name = $dataset_row['DATASET'];

        $datasetId = 0;
        // Get the right dataset ID
        if ($dataset_name === "DS3B") {
            $datasetId = 1; // Set the correct dataset_id for DS3B
        } elseif ($dataset_name === "DS6B") {
            $datasetId = 2; // Set the correct dataset_id for DS6B
        } elseif ($dataset_name === "DS7E") {
            $datasetId = 3; // Set the correct dataset_id for DS7E
        }


        // SQL query to fetch data from the column
        $sql3 = "SELECT raw_column_name FROM raw_column_data WHERE dataset_id = $datasetId";
        // Execute the query and get the result set
        $result3 = $conn->query($sql3);
        $row3 = mysqli_fetch_assoc($result3);

       
// Retrieve the record from the event_defination table based on the ID
$sql = "SELECT * FROM event_defination WHERE ed_id = $recordId";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

// Loop over each column name
foreach ($columnNames as $columnName) {
    echo '<label for="' . $columnName . '">' . $columnName . '</label>';
    echo '<br>';

    // Create a dropdown list with the fetched data as options
    echo '<select name="' . $columnName . '">';
    echo '<option value="">NULL</option>';
    while ($row3 = mysqli_fetch_assoc($result3)) {
        $optionValue = $row3["raw_column_name"];
        $selected = ($optionValue == $row[$columnName]) ? 'selected' : '';
       // echo '' . $optionValue . '"' . $selected . '';
        
        echo '<option value="' . $optionValue . '"' . $selected . '>' . $optionValue . '</option>';
    }

    // Reset the pointer to the beginning of the result set for the next dropdown list
    mysqli_data_seek($result3, 0);

    echo '</select>';
    echo '<br>';
    echo '<br>';
}
$conn->close();
            ?>

            <input type="submit" name="submit_data" value="Update Data">
        </form>
    </center>
</div>
</body>
</html>
