<html>
	<head>
	<title>Be Healthy - Admin</title>
	<link rel="stylesheet" type="text/css" href="mystyle.css">
	<!-- favicons
	================================================== -->
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
	<link rel="icon" href="favicon.ico" type="image/x-icon">
	</head>
	<body>
	<br/>
	<center>
	<font color="green" size="10"> Be Healthy</font>
	</center>
	<ul>
        <li><a href="dropdown.php">Create a new record</a></li>
        <li><a href="ed.php">Event Defination List</a></li>
        <li><a class="active" href="upload.php">Upload Dataset CSV file</a></li>
	</ul>
<div class="container">
<center>
		<h1>Upload CSV to MySQL</h1>
	<form method="POST" enctype="multipart/form-data">
		<label for="file">CSV file:</label>
   		<input type="file" name="file" id="file"><br>
		<input type="submit" name="submit" value="Upload">
	</form>

    <?php
    // MySQL database configuration
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "database";

    // Connect to the MySQL server
    $mysqli = new mysqli($host, $username, $password, $database);

    // Check connection
    if ($mysqli->connect_errno) {
        echo "Failed to connect to MySQL: " . $mysqli->connect_error;
        exit();
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Check if a file was uploaded
        if ($_FILES["file"]["error"] === UPLOAD_ERR_OK) {
            $csvFilePath = $_FILES["file"]["tmp_name"];

            // Get the file name
            $fileName = basename($_FILES["file"]["name"]);

            // Check the file name to select the correct dataset_id
            $datasetId = null;
            if ($fileName === "DS3B CARDIAC data.csv") {
                $datasetId = 1; // Set the correct dataset_id for DS3B CARDIAC data
            } elseif ($fileName === "DS6B BloodProductAudit clinical data.csv") {
                $datasetId = 2; // Set the correct dataset_id for DS6B BloodProductAudit clinical data
            } elseif ($fileName === "DS7E PAM Cardiac Surgery data.csv") {
                $datasetId = 3; // Set the correct dataset_id for DS7E PAM Cardiac Surgery data
            }

            if ($datasetId !== null) {
                // Read the CSV file
                $csvData = [];
                if (($handle = fopen($csvFilePath, "r")) !== false) {
                    while (($data = fgetcsv($handle, 1000, ",")) !== false) {
                        $csvData[] = $data;
                    }
                    fclose($handle);
                }

                // Read the CSV file into an array.
                $csv_data = array_map('str_getcsv', file($csvFilePath));

                // Extract the column headers from the first row of the CSV file.
                $headers = $csv_data[0];
				

                
// Add all header names to an array
$modified_headers = [];

// Append a sequential number to duplicate column headers to make them unique.
$header_counts = array_count_values($headers);

foreach ($headers as $header) {
    if ($header_counts[$header] > 1) {
        $suffix = 1;
        $modified_header = $header . "." . $suffix;

        while (in_array($modified_header, $modified_headers)) {
            $suffix++;
            $modified_header = $header . "." . $suffix;
        }
        // Remove the single quote from the modified header
        $modified_headers[] = str_replace("'", "", $modified_header); 
        
    } else {

        // Remove the single quote from the header
        $modified_headers[] = str_replace("'", "", $header); 
    }
}

// ...

               

               // ...

// Check if records with the same dataset_id already exist
$checkQuery = "SELECT COUNT(*) as count FROM raw_column_data WHERE dataset_id = $datasetId";
$result = $mysqli->query($checkQuery);
if ($result === false) {
    echo "Failed to check existing raw column data: " . $mysqli->error;
    exit();
}

$row = $result->fetch_assoc();
$count = $row['count'];

if ($count > 0) {
    echo "Data from dataset $fileName has already been inserted. Please try using another dataset.";
    exit();
}

// Insert the CSV data into the "raw_column_data" table
$insertRawColumnDataQuery = "INSERT INTO raw_column_data (dataset_id, raw_column_name) VALUES ";
foreach ($modified_headers as $header) {
    $insertRawColumnDataQuery .= "($datasetId, '$header'), ";
}
$insertRawColumnDataQuery = rtrim($insertRawColumnDataQuery, ", ");
$insertRawColumnDataQuery .= " ON DUPLICATE KEY UPDATE raw_column_name = VALUES(raw_column_name)";

if ($mysqli->query($insertRawColumnDataQuery) === false) {
    echo "Failed to insert raw column data: " . $mysqli->error;
    exit();
}

// ...



                echo "Uploaded dataset file '$fileName' has been processed and saved in the database with dataset_id: $datasetId<br>";
            } else {
                echo "Invalid file name. Please upload a valid dataset file.<br>";
            }
        } else {
            echo "Failed to upload file. Please try again.<br>";
        }
    }

    $mysqli->close();
    ?>
</center>
</div>		

	</body>
</html>
