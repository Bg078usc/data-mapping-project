<html>
	<head>
	<title>Be strong - Admin</title>
	<link rel="stylesheet" type="text/css" href="mystyle.css">
	<!-- favicons
	================================================== -->
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
	<link rel="icon" href="favicon.ico" type="image/x-icon">
	</head>
	<body>
	<br/>
	<center>
	<font color="green" size="10"> Be Strong</font>
	</center>
	<ul>
		<li><a href="dropdown.php">Create a new record</a></li>
		<li><a  class="active" href="ed.php">Event Defination List</a></li>
		<li><a href="upload.php">Upload Dataset CSV file</a></li>
	</ul>
<div class="container">
<center>

<?php
$conn =mysqli_connect("localhost","root","","database");

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Table name
$tableName = "ed";


// SQL query to fetch table structure (column names)
$sql = "DESCRIBE $tableName";

// Execute the query and get the result set
$result = $conn->query($sql);

if ($result === false) {
  // Query execution failed
  die("Error: " . $conn->error);
}

if ($result->num_rows > 0) {
  // Output table header
  echo "<table>";
  echo "<tr>";
  while ($row = $result->fetch_assoc()) {
    echo "<th>" . $row['Field'] . "</th>";
  }
  echo "</tr>";
  echo "</table>";
} else {
  echo "No data found in the table.";
}

// Close the database connection
$conn->close();
?>

</center>
</div>					
	</body>
</html>