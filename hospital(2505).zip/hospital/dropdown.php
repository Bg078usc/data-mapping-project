<html>
<head>
<title>Be strong - Admin</title>
<link rel="stylesheet" type="text/css" href="mystyle.css">
<!-- favicons
================================================== -->
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
<link rel="icon" href="favicon.ico" type="image/x-icon">
</head>
<body>
<br/>
<center>
<font color="green" size="10">Be Strong</font>
</center>
<ul>
    <li><a class="active" href="dropdown.php">Create a new record</a></li>
    <li><a href="ed.php">Event Definition List</a></li>
    <li><a href="upload.php">Upload Dataset CSV file</a></li>
</ul>
<div class="container">
<center>

    <label>Drop-down list by fetching the data from the database table</label>
    <br>

    <?php
    // MySQL connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "database";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    echo '<br>';
    echo '<br>';

    // Creating form to store the value of the dropdown option
    echo '<form method="POST">';

    echo '<label for="dataset">Select a dataset:</label>';

    // SQL query to fetch data from the column
    $sql1 = "SELECT dataset_name FROM dataset_list";
    // Execute the query and get the result set
    $result1 = $conn->query($sql1);

    // Create a dropdown list with the fetched data as options
    echo '<select name="dataset">';
    while ($row1 = $result1->fetch_assoc()) {
        echo '<option value="' . $row1["dataset_name"] . '">' . $row1["dataset_name"] . '</option>';
    }
    echo '</select>';

    echo '<br>';
    echo '<br>';
   
    echo '<br>';
    echo '<br>';
    echo '<input type="submit" name="submit" value="Submit">';
    echo '</form>';

    // Check if the form is submitted
    if (isset($_POST['submit'])) {
        // Retrieve the selected option value
        $dataset_name = $_POST['dataset'];


        // Print the selected option value
        echo "Selected Dataset: " . $dataset_name;
        echo '<br>';

        echo '<br>';
        echo '<br>';

        // Get the right dataset ID
        if ($dataset_name === "DS3B") {
            $datasetId = 1; // Set the correct dataset_id for DS3B
        } elseif ($dataset_name === "DS6B") {
            $datasetId = 2; // Set the correct dataset_id for DS6B
        } elseif ($dataset_name === "DS7E") {
            $datasetId = 3; // Set the correct dataset_id for DS7E
        }
         echo '<form name="ed" action="ed1.php" method="POST">';
         echo '<label for="event">Select an event:</label>';
         echo '<br>';


        // SQL query to fetch data from the column
        $sql2 = "SELECT event_list FROM event_list_ict342";
        // Execute the query and get the result set
        $result2 = $conn->query($sql2);

       echo '<input type="hidden" name="DATASET" value="' . $dataset_name . '">';


        // Create a dropdown list with the fetched data as options
        echo '<select name="event">';

        while ($row2 = $result2->fetch_assoc()) {
            echo '<option value="' . $row2["event_list"] . '">' . $row2["event_list"] . '</option>';
        }
        echo '</select>';
        echo '<br>';
        echo '<br>';


        // Fetch the data from the database
        $sql4 = "SELECT variableColumnName FROM standrd_name where standrdNameID > 1";
        $result4 = mysqli_query($conn, $sql4);

        // Check for errors in the query
        if (!$result4) {
            die("Query failed: " . $conn->error);
        }

        // Create an array to store the column names
        $columnNames = array();
        while ($row4 = mysqli_fetch_assoc($result4)) {
            $columnNames[] = $row4['variableColumnName'];
        }

        // SQL query to fetch data from the column
        $sql3 = "SELECT raw_column_name FROM raw_column_data WHERE dataset_id = $datasetId";
        // Execute the query and get the result set
        $result3 = $conn->query($sql3);

       

        foreach ($columnNames as $columnName) {
            echo '<label for="' . $columnName . '">' . $columnName . '</label>';
            echo '<br>';
            // Create a dropdown list with the fetched data as options
            echo '<select name="' . $columnName . '">';
            $result3->data_seek(0); // Reset the pointer to the beginning of the result set
            echo '<option value="">NULL</option>';
            while ($row3 = $result3->fetch_assoc()) {
                echo '<option value="' . $row3["raw_column_name"] . '">' . $row3["raw_column_name"] . '</option>';
            }
            echo '</select>';
            echo '<br>';
            echo '<br>';
        }

        echo '<input type="submit" name="submit_data" value="Submit Data">';
        echo '</form>';



    }




    // Close the database connection
    $conn->close();
    ?>

</center>
</div>
</body>
</html>
