    <?php
    // MySQL connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "database";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    echo '<br>';
    echo '<br>';

 

//Check if the form is submitted
if (isset($_POST['submit_data'])) {
    $DATASET=$_POST['DATASET'];
    $EVENT_NAME = $_POST['event'];
    $CLIN_DSET_DESCR=$_POST['CLIN_DSET_DESCR'];
    $CLIN_DSET_NAME=$_POST['CLIN_DSET_NAME'];
    $PK=$_POST['PK'];
    $PATIENT_ID=$_POST['PATIENT_ID'];
    $DOB=$_POST['DOB'];
    $SEX = $_POST['SEX'];
    $HEIGHT = $_POST['HEIGHT'];
    $WEIGHT = $_POST['WEIGHT'];
    $COMMENT = $_POST['COMMENT'];
    $PK_ORIGIN = $_POST['PK_ORIGIN'];
    $BOC_EVENT = $_POST['BOC_EVENT'];
    $CLOSEST_DATE = $_POST['CLOSEST_DATE'];
    $CLOSEST_DATE_EVENT = $_POST['CLOSEST_DATE_EVENT'];
    $HB = $_POST['HB'];
    $HCT = $_POST['HCT'];
    $RCC = $_POST['RCC'];
    $MCV = $_POST['MCV'];
    $RETIC = $_POST['RETIC'];
    $PRBC = $_POST['PRBC'];
    $HAEMOSTAT_INTERVENE = $_POST['HAEMOSTAT_INTERVENE'];
    $ON_PUMP = $_POST['ON_PUMP'];
    $PRIMARY_OPERATION = $_POST['PRIMARY_OPERATION'];
    $CS_URGENCY = $_POST['CS_URGENCY'];
    $DIAGNOSIS = $_POST['DIAGNOSIS'];
    $TREATMENT = $_POST['TREATMENT'];
    $RAW_DATA = $_POST['RAW_DATA'];

    // Print the selected options' values
    echo "DATASET: " . $DATASET . "<br>";
    echo "EVENT_NAME: " . $EVENT_NAME . "<br>";
    echo "CLIN_DSET_DESCR: " . $CLIN_DSET_DESCR . "<br>";
    echo "CLIN_DSET_NAME: " . $CLIN_DSET_NAME . "<br>";
    echo "PK: " . $PK . "<br>";
    echo "PATIENT_ID: " . $PATIENT_ID . "<br>";
    echo "DOB: " . $DOB . "<br>";
    echo "SEX: " . $SEX . "<br>";
    echo "HEIGHT: " . $HEIGHT . "<br>";
    echo "WEIGHT: " . $WEIGHT . "<br>";
    echo "COMMENT: " . $COMMENT . "<br>";
    echo "PK_ORIGIN: " . $PK_ORIGIN . "<br>";
    echo "BOC_EVENT: " . $BOC_EVENT . "<br>";
    echo "CLOSEST_DATE: " . $CLOSEST_DATE . "<br>";
    echo "CLOSEST_DATE_EVENT: " . $CLOSEST_DATE_EVENT . "<br>";
    echo "HB: " . $HB . "<br>";
    echo "HCT: " . $HCT . "<br>";
    echo "RCC: " . $RCC . "<br>";
    echo "MCV: " . $MCV . "<br>";
    echo "RETIC: " . $RETIC . "<br>";
    echo "PRBC: " . $PRBC . "<br>";
    echo "HAEMOSTAT_INTERVENE: " . $HAEMOSTAT_INTERVENE . "<br>";
    echo "ON_PUMP: " . $ON_PUMP . "<br>";
    echo "PRIMARY_OPERATION: " . $PRIMARY_OPERATION . "<br>";
    echo "CS_URGENCY: " . $CS_URGENCY . "<br>";
    echo "DIAGNOSIS: " . $DIAGNOSIS . "<br>";
    echo "TREATMENT: " . $TREATMENT . "<br>";
    echo "RAW_DATA: " . $RAW_DATA . "<br>";

    $sql = "INSERT INTO event_defination(`DATASET`,`EVENT`,  `CLIN.DSET.DESCR`, `CLIN.DSET.NAME`, `PK`, `PATIENT.ID`, `DOB`, `SEX`, `HEIGHT`, `WEIGHT`, `COMMENT`, `PK.ORIGIN`, `BOC.EVENT`, `CLOSEST.DATE`, `CLOSEST.DATE.EVENT`, `HB`, `HCT`, `RCC`, `MCV`, `RETIC`, `PRBC`, `HAEMOSTAT.INTERVENE`, `ON.PUMP`, `PRIMARY.OPERATION`, `CS.URGENCY`, `DIAGNOSIS`, `TREATMENT`, `RAW.DATA`) 
    VALUES ('$DATASET','$EVENT_NAME','$CLIN_DSET_DESCR','$CLIN_DSET_NAME','$PK','$PATIENT_ID','$DOB','$SEX','$HEIGHT','$WEIGHT','$COMMENT','$PK_ORIGIN','$BOC_EVENT','$CLOSEST_DATE','$CLOSEST_DATE_EVENT','$HB','$HCT','$RCC','$MCV','$RETIC','$PRBC','$HAEMOSTAT_INTERVENE','$ON_PUMP','$PRIMARY_OPERATION','$CS_URGENCY','$DIAGNOSIS','$TREATMENT','$RAW_DATA')";
    
            if(mysqli_query($conn,$sql))
                {
                    header("refresh:1.0; location:dropdown.php");
                }

   /*
    // Retrieve the selected options
    $selectedOptions = array();
    foreach ($_POST as $key => $value) {
        if ($key != 'submit_data') {
            $selectedOptions[$key] = $value;
        }
    }

    // Print the selected options
    echo "Selected Options:<br>";
    foreach ($selectedOptions as $columnName => $selectedOption) {
        echo "$columnName: $selectedOption<br>";
    }

*/
}

    // Close the database connection
    $conn->close();
    ?>

