-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 25, 2023 at 04:08 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database`
--

-- --------------------------------------------------------

--
-- Table structure for table `dataset_list`
--

DROP TABLE IF EXISTS `dataset_list`;
CREATE TABLE IF NOT EXISTS `dataset_list` (
  `dataset_id` int NOT NULL,
  `dataset_name` varchar(250) NOT NULL,
  PRIMARY KEY (`dataset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `dataset_list`
--

INSERT INTO `dataset_list` (`dataset_id`, `dataset_name`) VALUES
(1, 'DS3B'),
(2, 'DS6B'),
(3, 'DS7E');

-- --------------------------------------------------------

--
-- Table structure for table `ed`
--

DROP TABLE IF EXISTS `ed`;
CREATE TABLE IF NOT EXISTS `ed` (
  `DATASET` varchar(255) DEFAULT NULL,
  `PK` int DEFAULT NULL,
  `PATIENT_ID` int DEFAULT NULL,
  `EVENT` varchar(255) DEFAULT NULL,
  `CLOSEST_DATE` date DEFAULT NULL,
  `CLOSEST_DATE_EVENT` varchar(255) DEFAULT NULL,
  `HB` varchar(255) DEFAULT NULL,
  `HCT` varchar(255) DEFAULT NULL,
  `RCC` varchar(255) DEFAULT NULL,
  `MCV` varchar(255) DEFAULT NULL,
  `RETIC` varchar(255) DEFAULT NULL,
  `PRBC` varchar(255) DEFAULT NULL,
  `WEIGHT` varchar(255) DEFAULT NULL,
  `HAEMOSTAT_INTERVENE` varchar(255) DEFAULT NULL,
  `ON_PUMP` varchar(255) DEFAULT NULL,
  `PRIMARY_OPERATION` varchar(255) DEFAULT NULL,
  `CS_URGENCY` varchar(255) DEFAULT NULL,
  `DIAGNOSIS` varchar(255) DEFAULT NULL,
  `TREATMENT` varchar(255) DEFAULT NULL,
  `RAW_DATA` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `event_defination`
--

DROP TABLE IF EXISTS `event_defination`;
CREATE TABLE IF NOT EXISTS `event_defination` (
  `ed_id` int NOT NULL AUTO_INCREMENT,
  `DATASET` char(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `EVENT` varchar(500) NOT NULL,
  `CLIN.DSET.DESCR` char(100) DEFAULT NULL,
  `CLIN.DSET.NAME` char(100) DEFAULT NULL,
  `PK` char(100) DEFAULT NULL,
  `PATIENT.ID` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `DOB` text,
  `SEX` char(100) DEFAULT NULL,
  `HEIGHT` text,
  `WEIGHT` text,
  `COMMENT` char(100) DEFAULT NULL,
  `PK.ORIGIN` char(100) DEFAULT NULL,
  `BOC.EVENT` char(100) DEFAULT NULL,
  `CLOSEST.DATE` text,
  `CLOSEST.DATE.EVENT` char(100) DEFAULT NULL,
  `HB` text,
  `HCT` text,
  `RCC` text,
  `MCV` text,
  `RETIC` text,
  `PRBC` text,
  `HAEMOSTAT.INTERVENE` text,
  `ON.PUMP` char(100) DEFAULT NULL,
  `PRIMARY.OPERATION` char(100) DEFAULT NULL,
  `CS.URGENCY` char(100) DEFAULT NULL,
  `DIAGNOSIS` char(100) DEFAULT NULL,
  `TREATMENT` char(100) DEFAULT NULL,
  `RAW.DATA` char(100) DEFAULT NULL,
  PRIMARY KEY (`ed_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `event_defination`
--

INSERT INTO `event_defination` (`ed_id`, `DATASET`, `EVENT`, `CLIN.DSET.DESCR`, `CLIN.DSET.NAME`, `PK`, `PATIENT.ID`, `DOB`, `SEX`, `HEIGHT`, `WEIGHT`, `COMMENT`, `PK.ORIGIN`, `BOC.EVENT`, `CLOSEST.DATE`, `CLOSEST.DATE.EVENT`, `HB`, `HCT`, `RCC`, `MCV`, `RETIC`, `PRBC`, `HAEMOSTAT.INTERVENE`, `ON.PUMP`, `PRIMARY.OPERATION`, `CS.URGENCY`, `DIAGNOSIS`, `TREATMENT`, `RAW.DATA`) VALUES
(2, 'DS6B', 'SURGERY.WAITLIST', '', '', 'Primary Key', 'P', 'DOB', 'Gender', 'Height (cm)', 'Weight (kg)', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(3, 'DS6B', 'SURGERY.WAITLIST', '', '', 'Primary Key', 'P', 'DOB', 'Gender', 'Height (cm)', 'Weight (kg)', '', 'DOB', 'ICU Adm Source', '', '', '', '', 'OP Date', '', '', 'Procedure', '', 'OP Date', 'ICU Adm Date/Time', 'ICU Adm Source', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `event_list_ict342`
--

DROP TABLE IF EXISTS `event_list_ict342`;
CREATE TABLE IF NOT EXISTS `event_list_ict342` (
  `event_id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `event_list` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`event_id`),
  UNIQUE KEY `event_id` (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `event_list_ict342`
--

INSERT INTO `event_list_ict342` (`event_id`, `event_list`) VALUES
(1, 'PATHOLOGY'),
(2, 'PRBC'),
(3, 'SURGERY.WAITLIST'),
(4, 'PAM.ADMISSION'),
(5, 'PAM.INITIAL.CONTACT'),
(6, 'PAM.INITIAL.PATHOLOGY'),
(7, 'PAM.DIAGNOSIS'),
(8, 'PAM.TREATMENT'),
(9, 'PAM.FOLLOW.UP.PATHOLOGY'),
(10, 'PAM.TREATMENT.CURTAIL'),
(11, 'HOSP.PRE.ADMISSION'),
(12, 'HOSP.PRE.ADMISSION.PATHOLOGY'),
(13, 'HOSP.ADMISSION'),
(14, 'PREOPERATIVE.PATHOLOGY'),
(15, 'PREOPERATIVE.PRBC'),
(16, 'PREOPERATIVE.MORTALITY'),
(17, 'SURGERY.DIAGNOSIS'),
(18, 'SURGERY'),
(19, 'SURGERY.TREATMENT'),
(20, 'INTRAOPERATIVE.PATHOLOGY'),
(21, 'INTRAOPERATIVE.PRBC'),
(22, 'ICU.ADMISSION'),
(23, 'ICU.PATHOLOGY'),
(24, 'ICU.PRBC'),
(25, 'POSTOPERATIVE.PATHOLOGY'),
(26, 'POSTOPERATIVE.PRBC'),
(27, 'ICU.DISCHARGE'),
(28, 'WARD.PATHOLOGY'),
(29, 'WARD.PRBC'),
(30, 'HOSP.DISCHARGE'),
(31, 'FINAL.PATHOLOGY'),
(32, 'POSTOPERATIVE.MORTALITY');

-- --------------------------------------------------------

--
-- Table structure for table `raw_column_data`
--

DROP TABLE IF EXISTS `raw_column_data`;
CREATE TABLE IF NOT EXISTS `raw_column_data` (
  `raw_column_id` int NOT NULL AUTO_INCREMENT,
  `dataset_id` int NOT NULL,
  `raw_column_name` varchar(500) NOT NULL,
  PRIMARY KEY (`raw_column_id`),
  KEY `dataset_id` (`dataset_id`)
) ENGINE=InnoDB AUTO_INCREMENT=885 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `raw_column_data`
--

INSERT INTO `raw_column_data` (`raw_column_id`, `dataset_id`, `raw_column_name`) VALUES
(213, 2, 'Primary Key'),
(214, 2, 'Patient ID'),
(215, 2, '2017 Book Number'),
(216, 2, 'DOB'),
(217, 2, 'Gender'),
(218, 2, 'AGE ON ICU ADM'),
(219, 2, 'ICU Adm Date/Time'),
(220, 2, 'Weight (kg)'),
(221, 2, 'Height (cm)'),
(222, 2, 'Height (m)'),
(223, 2, 'BMI'),
(224, 2, 'ICU Adm Source'),
(225, 2, 'TLO'),
(226, 2, 'OP Date'),
(227, 2, 'Procedure'),
(228, 2, 'YES'),
(229, 2, 'REOPEN Bleeding DetailsY/N'),
(230, 2, 'Re Open Date'),
(231, 2, 'Reopen Location'),
(232, 2, 'PRC'),
(233, 2, 'FFP.1'),
(234, 2, 'Plt.1'),
(235, 2, 'CRYO.1'),
(236, 2, 'CRYA.1'),
(237, 2, 'ELP.1'),
(238, 2, 'Vit K.1'),
(239, 2, 'Factor 7.1'),
(240, 2, 'Prothrombinex.1'),
(241, 2, 'Thrombotrol.1'),
(242, 2, 'Fibrinogen (Dose).1'),
(243, 2, 'DDAVP.1'),
(244, 2, 'Other.1'),
(245, 2, 'Approtonin.1'),
(246, 2, 'TXA (dose).1'),
(247, 2, 'Protamine MOT.1'),
(248, 2, 'blood loss at time of reopen'),
(249, 2, 'Site'),
(250, 2, 'Transf Reaction Y/N'),
(251, 2, 'Bloods Pre Op Hb'),
(252, 2, 'Bloods Pre Op HCT'),
(253, 2, 'Bloods Pre Op Plts'),
(254, 2, 'Bloods Pre Op Fib (d)'),
(255, 2, 'Bloods Post Op Hb'),
(256, 2, 'Bloods Post Op Plt'),
(257, 2, 'Bloods Post Op Fib (d)'),
(258, 2, 'Blood Group '),
(259, 2, 'Last Hb'),
(260, 2, 'ICU Obs Blood Loss 2 hrs'),
(261, 2, 'ICU Obs Blood Loss 4hrs'),
(262, 2, 'ICU Obs Blood Loss 12hrs'),
(263, 2, 'ICU Obs Blood Loss 24hrs'),
(264, 2, 'Haemostasis Mgt MOT RBC'),
(265, 2, 'FFP.2'),
(266, 2, 'Plt.2'),
(267, 2, 'CRYO.2'),
(268, 2, 'CRYA.2'),
(269, 2, 'ELP.2'),
(270, 2, 'Vit K.2'),
(271, 2, 'Factor 7.2'),
(272, 2, 'Prothrombinex.2'),
(273, 2, 'Thrombotrol.2'),
(274, 2, 'Fibrinogen (Dose).2'),
(275, 2, 'DDAVP.2'),
(276, 2, 'Biostate'),
(277, 2, 'Haemostasis Mgt ICU RBC'),
(278, 2, 'FFP.3'),
(279, 2, 'Plt.3'),
(280, 2, 'CRYO.3'),
(281, 2, 'CRYA.3'),
(282, 2, 'ELP.3'),
(283, 2, 'Vit K.3'),
(284, 2, 'Factor 7.3'),
(285, 2, 'Prothrombinex.3'),
(286, 2, 'Fibrinogen (Dose).3'),
(287, 2, 'DDAVP.3'),
(288, 2, 'Other.2'),
(289, 2, 'Haemostasis Mgt Ward RBC'),
(290, 2, 'FFP.4'),
(291, 2, 'Plt.4'),
(292, 2, 'CRYO.4'),
(293, 2, 'CRYA.4'),
(294, 2, 'ELP.4'),
(295, 2, 'Vit K.4'),
(296, 2, 'Fibrinogen (Dose).4'),
(297, 2, 'Prothrombinex.4'),
(298, 2, 'Other.3'),
(299, 2, 'Approtonin.2'),
(300, 2, 'TXA (dose).2'),
(301, 2, 'Protamine MOT.2'),
(302, 2, 'Protamine ICU'),
(303, 2, 'Multiplate'),
(304, 2, 'UNKNOWN'),
(305, 2, 'Creat Pre/Adm ICU'),
(306, 2, 'Creat Postop'),
(307, 2, 'Comments'),
(308, 2, 'ICU READMISSION'),
(309, 2, 'DATE OF SURGERY'),
(597, 1, 'PRIMARY KEY'),
(598, 1, 'Patient ID'),
(599, 1, 'DATE_OF_BIRTH'),
(600, 1, 'GENDER'),
(601, 1, 'ADMISSION_DATE'),
(602, 1, 'DISCHARGE_DATE'),
(603, 1, 'SURGERY_DATE'),
(604, 1, 'VERIFIED COMMENT'),
(605, 1, 'SMOKING_HISTORY'),
(606, 1, 'CURRENT_SMOKER'),
(607, 1, 'DIABETES'),
(608, 1, 'DIABETES_CONTROL'),
(609, 1, 'HYPERCHOLESTEROLAEMIA'),
(610, 1, 'PRE_OP_HAEMOGLOBIN'),
(611, 1, 'RENAL_DIALYSIS'),
(612, 1, 'RENAL_TRANSPLANT'),
(613, 1, 'CEREBROVASULAR_DISEASE'),
(614, 1, 'CEREBROVASCULAR_DISEASE_TYPE'),
(615, 1, 'HYPERTENSION'),
(616, 1, 'INFECTIVE_ENDOCARDITIS'),
(617, 1, 'INFECTIVE_ENDOCARDITIS_TYPE'),
(618, 1, 'IMMUNOSUPPRESSIVE_THERAPY'),
(619, 1, 'RESPIRATORY_DISEASE'),
(620, 1, 'RESPIRATORY_DISEASE_TYPE'),
(621, 1, 'EUROSCORE_2'),
(622, 1, 'PERIPHERAL_VASCULAR_DISEASE'),
(623, 1, 'CVA_CAROTID_TEST_RESULT'),
(624, 1, 'CVA_WHEN'),
(625, 1, 'PRE_OP_CREATININE'),
(626, 1, 'ANGINA_FULL_DOSE_HEPARINOIDS'),
(627, 1, 'ANGINA_IV_GTN'),
(628, 1, 'ANGINA_IV_HEPARIN'),
(629, 1, 'ARRHYTHMIA'),
(630, 1, 'ARRHYTHMIA_ATRIAL'),
(631, 1, 'ARRHYTHMIA_ATRIAL_TYPE'),
(632, 1, 'ARRHYTHMIA_HEART_BLOCK'),
(633, 1, 'ARRHYTHMIA_OTHER'),
(634, 1, 'ARRHYTHMIA_VENTRICULAR'),
(635, 1, 'ANTIPLTLT_ABCIXIMAB'),
(636, 1, 'ANTIPLTLT_GLYCPRTN_INHIB'),
(637, 1, 'ANTIPLTLT_ASPIRIN'),
(638, 1, 'ANTIPLTLT_THIENOPYRIDINE'),
(639, 1, 'ANTIPLTLT_OTHER'),
(640, 1, 'ANTIPLTLT_TICAGRELOR'),
(641, 1, 'MEDICATIONS_ANTICOAGULANT'),
(642, 1, 'ANTIPLTLT_GLYCPRTN_INHIB_WHEN'),
(643, 1, 'ANTIPLTLT_ABCIXIMAB_WHEN'),
(644, 1, 'ANTIPLTLT_ASPIRIN_WHEN'),
(645, 1, 'ANTIPLTLT_THIENOPYRIDINE_WHEN'),
(646, 1, 'ANTIPLTLT_OTHER_WHEN'),
(647, 1, 'ANTIPLTLT_TICAGRELOR_WHEN'),
(648, 1, 'MEDICATIONS_INOTROPE'),
(649, 1, 'MEDICATIONS_IV_GTN'),
(650, 1, 'MEDICATIONS_STEROID'),
(651, 1, 'PRIOR_OPEN_CARDIAC_SURGERY'),
(652, 1, 'PRIOR_LAA_OCCLUSION'),
(653, 1, 'PRIOR_PERCUT_VALVULOPLASTY'),
(654, 1, 'PRIOR_CABG'),
(655, 1, 'PCI_ASD'),
(656, 1, 'PCI_VSD'),
(657, 1, 'PTMVR'),
(658, 1, 'PRIOR_OTHER_CARDIAC_SURGERY'),
(659, 1, 'PRIOR_PERCUTANEOUS_MV_REPAIR'),
(660, 1, 'PRIOR_CTS_INTERVENTION'),
(661, 1, 'PRIOR_OFF_PUMP_CABG'),
(662, 1, 'PRIOR_PCI'),
(663, 1, 'PRIOR_TAVI'),
(664, 1, 'PRIOR_PTCA_STENT'),
(665, 1, 'PRIOR_PTCA_STENT_ADMISSION'),
(666, 1, 'PRIOR_VALVE_SURGERY'),
(667, 1, 'PRIOR_EP_ABLATION'),
(668, 1, 'PRIOR_SURGERIES_WITHOUT_CPB'),
(669, 1, 'PRIOR_SURGERIES_WITH_CPB'),
(670, 1, 'PCI_H'),
(671, 1, 'NUMBER_OF_DISEASED_VESSELS'),
(672, 1, 'LVEF_PERCENTAGE'),
(673, 1, 'LEFT_MAIN_STENOSIS_OVER_50_PCT'),
(674, 1, 'WEIGHT_KGS'),
(675, 1, 'HEIGHT_CMS'),
(676, 1, 'CARDIAC_CATH_ANGIOGRAM'),
(677, 1, 'CARDIAC_CATH_ANGIOGRAM_DATE'),
(678, 1, 'LVEF_ESTIMATE'),
(679, 1, 'LVEF_METHOD'),
(680, 1, 'ATRIAL_ARRHYTHMIA_SURGERY'),
(681, 1, 'AORTIC_PROCEDURE'),
(682, 1, 'CABG'),
(683, 1, 'OTHER_CARDIAC_SURGERY'),
(684, 1, 'LV_ANEURYSM_REPAIR'),
(685, 1, 'VSD_ACQUIRED_REPAIR'),
(686, 1, 'ATRIAL_SEPTAL_DEFECT_REPAIR'),
(687, 1, 'CARDIAC_TRAUMA_REPAIR'),
(688, 1, 'LVOT_MYECTOMY_FOR_HOCM'),
(689, 1, 'LV_RUPTURE_REPAIR'),
(690, 1, 'PERICARDIECTOMY'),
(691, 1, 'PULM_THROMBOENDARTERECTOMY'),
(692, 1, 'LV_RECONSTRUCTION'),
(693, 1, 'PULMONARY_EMBOLECTOMY'),
(694, 1, 'CARDIAC_TUMOUR'),
(695, 1, 'CARDIAC_TRANSPLANT'),
(696, 1, 'CARDIOPULMONARY_TRANSPLANT'),
(697, 1, 'LUNG_TRANSPLANT'),
(698, 1, 'OTHER_CONGENITAL_SURGERY'),
(699, 1, 'PERMANENT_LV_EPICARDIAL_LEAD'),
(700, 1, 'VALVE_SURGERY'),
(701, 1, 'NON_CARDIAC_SURGERY'),
(702, 1, 'STATUS'),
(703, 1, 'URGENT_PROCEDURE_REASON'),
(704, 1, 'CARDIAC_PROCEDURE'),
(705, 1, 'MINIMALLY_INVASIVE_TECHNIQUE'),
(706, 1, 'OFF_PUMP'),
(707, 1, 'CUMULATIVE_CROSS_CLAMP_TIME'),
(708, 1, 'CARDIOPULMONARY_BYPASS_USED'),
(709, 1, 'IABP'),
(710, 1, 'IABP_WHEN'),
(711, 1, 'INTRA_OP_ANTIFIBRINOLYTIC'),
(712, 1, 'INTRA_OP_ANTIFIBRINOLYTIC_TYPE'),
(713, 1, 'CARDIOPLEGIA'),
(714, 1, 'CPLEG_T'),
(715, 1, 'ECMO'),
(716, 1, 'ECMO_INDICATION'),
(717, 1, 'ECMO_WHEN'),
(718, 1, 'IABP_INDICATION'),
(719, 1, 'INTRA_OP_TOE'),
(720, 1, 'VAD'),
(721, 1, 'INTRA_OP_HAEMOGLOBIN'),
(722, 1, 'CUMULATIVE_CPB_PERFUSION_TIME'),
(723, 1, 'VAD_INDICATION'),
(724, 1, 'VAD_WHEN'),
(725, 1, 'ICU_ADMISSION_DATE_TIME'),
(726, 1, 'ICU_DISCHARGE_DATE_TIME'),
(727, 1, 'ICC_LOSS_FIRST_FOUR_HOURS'),
(728, 1, 'EXTUBATION_DATE_TIME'),
(729, 1, 'NON_RBC_USED'),
(730, 1, 'CRYOUNIT'),
(731, 1, 'FFPUNIT'),
(732, 1, 'PLATEUNIT'),
(733, 1, 'NOVOUNIT'),
(734, 1, 'RBC_USED'),
(735, 1, 'RBCUNIT'),
(736, 1, 'REEXTUBATION_DATE_TIME'),
(737, 1, 'REINTUBATION_DATE_TIME'),
(738, 1, 'READMITTED_TO_ICU'),
(739, 1, 'REINTUBATION'),
(740, 1, 'NEW_ANTICOAGULANT_COMPLICATION'),
(741, 1, 'NEW_ATRIAL_ARRYTHMIA'),
(742, 1, 'NEW_ARRHYTHMIA_REQUIRING_PPM'),
(743, 1, 'NEW_CARDIAC_ARREST'),
(744, 1, 'INOTROPE_MORE_THAN_4_HOURS'),
(745, 1, 'NEW_COMA_MORE_THAN_24_HOURS'),
(746, 1, 'NEW_STROKE_PERMANENT'),
(747, 1, 'NEW_STROKE_TRANSIENT'),
(748, 1, 'NEW_DONOR_SITE_WOUND_INFECT'),
(749, 1, 'NEW_GIT_COMPLICATION'),
(750, 1, 'NEW_HAEMOFILTRATION_REQUIRED'),
(751, 1, 'NEW_HEART_BLOCK_REQUIRING_PPM'),
(752, 1, 'NEW_DEEP_STERNAL_WOUND_INFECT'),
(753, 1, 'NEW_INFECTION_LEG_OR_ARM'),
(754, 1, 'NEW_SEPTICAEMIA'),
(755, 1, 'NEW_INFECTION_PARASTERNAL_SITE'),
(756, 1, 'INOTROPE_LOW_CARDIAC_OUTPUT'),
(757, 1, 'CARDIAC_VASOPRESSOR_LOW_SVR'),
(758, 1, 'NEW_ACUTE_LIMB_ISCHAEMIA'),
(759, 1, 'NEW_MULTI_SYSTEM_FAILURE'),
(760, 1, 'NEW_AORTIC_DISSECTION'),
(761, 1, 'NEW_CARDIAC_ARRHYTHMIA'),
(762, 1, 'NEW_VENTRICULAR_TACHYCARDIA'),
(763, 1, 'NEW_RENAL_FAILURE'),
(764, 1, 'PERI_OP_CARDIOGENIC_SHOCK'),
(765, 1, 'PERI_OP_MI'),
(766, 1, 'NEW_PULMONARY_EMBOLISM'),
(767, 1, 'NEW_PLEURAL_EFFUSION'),
(768, 1, 'NEW_PNEUMOTHORAX'),
(769, 1, 'NEW_PNEUMONIA'),
(770, 1, 'RETURN_TO_THEATRE'),
(771, 1, 'RTT_VALVE_DYSFUNCTION'),
(772, 1, 'RTT_BLEEDING_TAMPONADE'),
(773, 1, 'RTT_GRAFT_OCCLUSION'),
(774, 1, 'RTT_DEEP_STERNAL_INFECTION'),
(775, 1, 'RTT_THOROCOTOMY_INFECTION'),
(776, 1, 'RTT_INSERTION_PACEMAKER'),
(777, 1, 'RTT_OTHER_CARDIAC'),
(778, 1, 'RTT_OTHER_NON_CARDIAC'),
(779, 1, 'RTT_REASON'),
(780, 1, 'NEW_SUPERFICIAL_WOUND_INFECT'),
(781, 1, 'PROLONGED_VENTILATION'),
(782, 1, 'HIGHEST_POST_OP_CREATININE_LVL'),
(783, 1, 'POST_OP_HAEMOGLOBIN'),
(784, 1, 'DISCHARGE_LOCATION'),
(785, 1, 'MORTALITY_DATE'),
(786, 1, 'MORTALITY_LOCATION'),
(787, 1, 'MORTALITY_PRIMARY_CAUSE'),
(788, 1, 'MORTALITY_SUBSEQUENT_CAUSE'),
(789, 1, 'MORTALITY_POST_DISCHARGE'),
(790, 1, 'READMIT_IN_30_DAYS'),
(791, 1, 'READMIT_30_REASON'),
(792, 1, 'READMIT_30_ANTICOAGULANT'),
(793, 1, 'READMIT_30_ARRHYTHMIA'),
(794, 1, 'READMIT_30_CHF'),
(795, 1, 'READMIT_30_TAMPONADE'),
(796, 1, 'READMIT_30_DEEP_STERNAL_INFECT'),
(797, 1, 'READMIT_30_INCISIONAL_COMPL'),
(798, 1, 'READMIT_30_MI'),
(799, 1, 'READMIT_30_OTHER_CS_RELATED'),
(800, 1, 'READMIT_30_NOT_RELATED_TO_CS'),
(801, 1, 'READMIT_30_PERICARDIAL_EFFSN'),
(802, 1, 'READMIT_30_PLEURAL_EFFSN'),
(803, 1, 'READMIT_30_RECURRENT_ANGINA'),
(804, 1, 'READMIT_30_PNEUMONIA'),
(805, 1, 'READMIT_30_VALVE_DYSFUNCTION'),
(806, 1, 'OTHER_CARDIAC_PROCEDURE'),
(807, 1, 'LEFT_ATRIAL_APPENDAGE_CLOSURE'),
(808, 1, 'POSTOP_COMPLICATIONS'),
(809, 3, 'Primary Key'),
(810, 3, 'Date referred to CNC'),
(811, 3, 'Referred / Identified by (eg. OPD, GP, PREAC, DOA, SPAC)'),
(812, 3, 'Follow up Date'),
(813, 3, 'Patient ID'),
(814, 3, 'DOB'),
(815, 3, 'Gender'),
(816, 3, 'Date of Contact'),
(817, 3, 'Surgical Specialty (eg. Ortho, Card, Gen) / Consultant'),
(818, 3, 'Surgical Category (1, 2, 3)'),
(819, 3, 'Date Waitlisted'),
(820, 3, 'Proposed Surgery Date'),
(821, 3, 'Was Surgery Postponed due to anaemia.1'),
(822, 3, 'Pathology Date'),
(823, 3, 'Hb.1'),
(824, 3, 'RCC .1'),
(825, 3, 'MCV.1'),
(826, 3, 'Ferritin.1'),
(827, 3, 'Transferrin.1'),
(828, 3, 'TIBC.1'),
(829, 3, 'Tsat.1'),
(830, 3, 'ESR.1'),
(831, 3, 'CRP.1'),
(832, 3, 'Creat.1'),
(833, 3, 'eGFR.1'),
(834, 3, 'ALT.1'),
(835, 3, 'GGT.1'),
(836, 3, 'B12 .1'),
(837, 3, 'Fol.1'),
(838, 3, 'TSH.1'),
(839, 3, 'FOB.1'),
(840, 3, 'Pathologist (eg. QHPS, QML, S&N).1'),
(841, 3, 'Anaemia Type (eg. IDA, Unknown origin)'),
(842, 3, 'Treatment (eg. Iron PO/ IV, EPO, GP / Specialist referral'),
(843, 3, 'If Required - DUIT Appointment Date'),
(844, 3, 'DUIT Booked'),
(845, 3, 'Specialist Details (Type / Appt. Date)'),
(846, 3, 'Follow-up Pathology Date'),
(847, 3, 'Pathologist (eg. QHPS, QML, S&N).2'),
(848, 3, 'Hb.2'),
(849, 3, 'RCC .2'),
(850, 3, 'MCV.2'),
(851, 3, 'Retic'),
(852, 3, 'DAT'),
(853, 3, 'Ferritin.2'),
(854, 3, 'Transferrin.2'),
(855, 3, 'TIBC.2'),
(856, 3, 'Tsat.2'),
(857, 3, 'sTfr'),
(858, 3, 'ESR.2'),
(859, 3, 'CRP.2'),
(860, 3, 'Creat.2'),
(861, 3, 'eGFR.2'),
(862, 3, 'ALT.2'),
(863, 3, 'GGT.2'),
(864, 3, 'B12 .2'),
(865, 3, 'Fol.2'),
(866, 3, 'TSH.2'),
(867, 3, 'FOB.2'),
(868, 3, 'Preadmission Clinic Date'),
(869, 3, 'Surgery Date'),
(870, 3, 'Was Surgery Postponed due to anaemia.2'),
(871, 3, 'Date of Admission'),
(872, 3, 'Date of Discharge'),
(873, 3, 'Length of Stay'),
(874, 3, 'Median LOS per SPI'),
(875, 3, 'Preop Hb'),
(876, 3, 'Postop Hb'),
(877, 3, 'Lowest Post op Hb'),
(878, 3, 'D/C Hb'),
(879, 3, 'Preop RBC     (# of units)'),
(880, 3, 'Intraop RBC      (# of units)'),
(881, 3, '0-48hrs RBC     (# of units)'),
(882, 3, '49hrs - D/C RBC (# of units)'),
(883, 3, '6 week post op ph Call date'),
(884, 3, 'Notes / Qnaire completed');

-- --------------------------------------------------------

--
-- Table structure for table `standrd_name`
--

DROP TABLE IF EXISTS `standrd_name`;
CREATE TABLE IF NOT EXISTS `standrd_name` (
  `standrdNameID` int NOT NULL AUTO_INCREMENT,
  `variableColumnName` varchar(500) NOT NULL,
  PRIMARY KEY (`standrdNameID`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `standrd_name`
--

INSERT INTO `standrd_name` (`standrdNameID`, `variableColumnName`) VALUES
(1, 'DATASET'),
(2, 'CLIN.DSET.DESCR'),
(3, 'CLIN.DSET.NAME'),
(4, 'PK'),
(5, 'PATIENT.ID'),
(6, 'DOB'),
(7, 'SEX'),
(8, 'HEIGHT'),
(9, 'WEIGHT'),
(10, 'COMMENT'),
(11, 'PK.ORIGIN'),
(12, 'BOC.EVENT'),
(13, 'CLOSEST.DATE'),
(14, 'CLOSEST.DATE.EVENT'),
(15, 'HB'),
(16, 'HCT'),
(17, 'RCC'),
(18, 'MCV'),
(19, 'RETIC'),
(20, 'PRBC'),
(21, 'HAEMOSTAT.INTERVENE'),
(22, 'ON.PUMP'),
(23, 'PRIMARY.OPERATION'),
(24, 'CS.URGENCY'),
(25, 'DIAGNOSIS'),
(26, 'TREATMENT'),
(27, 'RAW.DATA');

-- --------------------------------------------------------

--
-- Table structure for table `variable_defination`
--

DROP TABLE IF EXISTS `variable_defination`;
CREATE TABLE IF NOT EXISTS `variable_defination` (
  `DATASET` char(100) DEFAULT NULL,
  `CLIN.DSET.DESCR` char(100) DEFAULT NULL,
  `CLIN.DSET.NAME` char(100) DEFAULT NULL,
  `PK` char(100) DEFAULT NULL,
  `PATIENT.ID` int DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `SEX` char(100) DEFAULT NULL,
  `HEIGHT` decimal(10,2) DEFAULT NULL,
  `WEIGHT` decimal(10,2) DEFAULT NULL,
  `COMMENT` char(100) DEFAULT NULL,
  `PK.ORIGIN` char(100) DEFAULT NULL,
  `BOC.EVENT` char(100) DEFAULT NULL,
  `CLOSEST.DATE` date DEFAULT NULL,
  `CLOSEST.DATE.EVENT` char(100) DEFAULT NULL,
  `HB` decimal(10,2) DEFAULT NULL,
  `HCT` decimal(10,2) DEFAULT NULL,
  `RCC` decimal(10,2) DEFAULT NULL,
  `MCV` decimal(10,2) DEFAULT NULL,
  `RETIC` decimal(10,2) DEFAULT NULL,
  `PRBC` decimal(10,2) DEFAULT NULL,
  `HAEMOSTAT.INTERVENE` int DEFAULT NULL,
  `ON.PUMP` char(100) DEFAULT NULL,
  `PRIMARY.OPERATION` char(100) DEFAULT NULL,
  `CS.URGENCY` char(100) DEFAULT NULL,
  `DIAGNOSIS` char(100) DEFAULT NULL,
  `TREATMENT` char(100) DEFAULT NULL,
  `RAW.DATA` char(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `raw_column_data`
--
ALTER TABLE `raw_column_data`
  ADD CONSTRAINT `raw_column_data_ibfk_1` FOREIGN KEY (`dataset_id`) REFERENCES `dataset_list` (`dataset_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
