<html>
	<head>
	<title>Be strong - Admin</title>
	<link rel="stylesheet" type="text/css" href="mystyle.css">
	<!-- favicons
	================================================== -->
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
	<link rel="icon" href="favicon.ico" type="image/x-icon">
	</head>
	<body>
	<br/>
	<center>
	<font color="green" size="10"> Be Strong</font>
	</center>
	<ul>
		<li><a href="dropdown.php">Create a new record</a></li>
		<li><a  class="active" href="ed.php">Event Defination List</a></li>
		<li><a href="upload.php">Upload Dataset CSV file</a></li>
	</ul>
<div class="container">
<center>

<?php
$conn =mysqli_connect("localhost","root","","database");

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

/// Step 2: Execute a SQL query to fetch all the data from the table
$sql = "SELECT * FROM event_defination";
$result = mysqli_query($conn, $sql);

// Step 3: Display the data in an HTML table
echo "<table>";
echo "<tr>";
while ($fieldinfo = mysqli_fetch_field($result)) {
    echo "<th>" . $fieldinfo->name . "</th>";
}
	

	echo "<th>UPDATE</th>";
	echo "<th>DELETE </th>";
echo "</tr>";

while ($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    for ($i=0; $i<mysqli_num_fields($result); $i++) {
        echo "<td>" . $row[$i] . "</td>";
    }
    // Step 4: Add CRUD options for each row of data
    echo "<td><a href='update.php?id=" . $row['ed_id'] . "'>Update</a></td>";
    echo "<td><a href='ed_delete.php?id=" . $row['ed_id'] . "'>Delete</a></td>";
    echo "</tr>";
}
echo "</table>";
$conn->close();
?>

</center>
</div>					
	</body>
</html>