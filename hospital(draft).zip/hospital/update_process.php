<?php
$con = mysqli_connect("localhost", "root", "", "database");

// Check if the form is submitted
if (isset($_POST['submit_data'])) {
    $ed_id = $_POST['record_id'];

    $CLIN_DSET_DESCR = $_POST['CLIN_DSET_DESCR'];
    $CLIN_DSET_NAME = $_POST['CLIN_DSET_NAME'];
    $PK = $_POST['PK'];
    $PATIENT_ID = $_POST['PATIENT_ID'];
    $DOB = $_POST['DOB'];
    $SEX = $_POST['SEX'];
    $HEIGHT = $_POST['HEIGHT'];
    $WEIGHT = $_POST['WEIGHT'];
    $COMMENT = $_POST['COMMENT'];
    $PK_ORIGIN = $_POST['PK_ORIGIN'];
    $BOC_EVENT = $_POST['BOC_EVENT'];
    $CLOSEST_DATE = $_POST['CLOSEST_DATE'];
    $CLOSEST_DATE_EVENT = $_POST['CLOSEST_DATE_EVENT'];
    $HB = $_POST['HB'];
    $HCT = $_POST['HCT'];
    $RCC = $_POST['RCC'];
    $MCV = $_POST['MCV'];
    $RETIC = $_POST['RETIC'];
    $PRBC = $_POST['PRBC'];
    $HAEMOSTAT_INTERVENE = $_POST['HAEMOSTAT_INTERVENE'];
    $ON_PUMP = $_POST['ON_PUMP'];
    $PRIMARY_OPERATION = $_POST['PRIMARY_OPERATION'];
    $CS_URGENCY = $_POST['CS_URGENCY'];
    $DIAGNOSIS = $_POST['DIAGNOSIS'];
    $TREATMENT = $_POST['TREATMENT'];
    $RAW_DATA = $_POST['RAW_DATA'];

    $sql = "UPDATE event_defination SET
        
        `CLIN.DSET.DESCR` = '$CLIN_DSET_DESCR',
        `CLIN.DSET.NAME` = '$CLIN_DSET_NAME',
        `PK` = '$PK',
        `PATIENT.ID` = '$PATIENT_ID',
        `DOB` = '$DOB',
        `SEX` = '$SEX',
        `HEIGHT` = '$HEIGHT',
        `WEIGHT` = '$WEIGHT',
        `COMMENT` = '$COMMENT',
        `PK.ORIGIN` = '$PK_ORIGIN',
        `BOC.EVENT` = '$BOC_EVENT',
        `CLOSEST.DATE` = '$CLOSEST_DATE',
        `CLOSEST.DATE.EVENT` = '$CLOSEST_DATE_EVENT',
        `HB` = '$HB',
        `HCT` = '$HCT',
        `RCC` = '$RCC',
        `MCV` = '$MCV',
        `RETIC` = '$RETIC',
        `PRBC` = '$PRBC',
        `HAEMOSTAT.INTERVENE` = '$HAEMOSTAT_INTERVENE',
        `ON.PUMP` = '$ON_PUMP',
        `PRIMARY.OPERATION` = '$PRIMARY_OPERATION',
        `CS.URGENCY` = '$CS_URGENCY',
        `DIAGNOSIS` = '$DIAGNOSIS',
        `TREATMENT` = '$TREATMENT',
        `RAW.DATA` = '$RAW_DATA'
    WHERE ed_id = $ed_id";

    if (mysqli_query($con, $sql)) {
        echo "Record updated successfully";
        header("refresh:0.2; url=ed.php");
    } else {
        echo "Error updating record: " . mysqli_error($con);
    }
}

mysqli_close($con);
?>
